<!--Header-->
 <?php include('./inc/header.php'); ?>
<!--Slider-->
 <?php include('./inc/slider.php'); ?>
<!---->
<script src="js/bootstrap.js"> </script>
<!--Deals-->
 <?php include('./inc/index_deals.php'); ?>
<!--Suscribe Part-->

<!--Footer Part-->
<?php include("./inc/footer.php"); ?>