 
 <!--Header-->
 <?php include('./inc/header.php'); ?>

<!---->
	
<div class="container">
	  <ol class="breadcrumb" >
		  <li><a href="index.php">Home</a></li>
		  <li class="active">User Account</li>
		  <li class="active">Saved Address</li>
		 </ol>
	 <div class="registration">
		 <div class="registration_left">
			 <h2> Change  <span> Password  </span></h2>
			 <!-- [if IE] 
				< link rel='stylesheet' type='text/css' href='ie.css'/>  
			 [endif] -->  
			  
			 <!-- [if lt IE 7]>  
				< link rel='stylesheet' type='text/css' href='ie6.css'/>  
			 <! [endif] -->  
			 
			 <div class="registration_form">
			 <!-- Form -->
				
	

				<!-- /Form -->
			 </div>
		 </div>
		 
		 <div class="clearfix"></div>
	 </div>
</div>

<?php include("./inc/suscribe.php"); ?>
<!--Footer Part-->
<?php include("./inc/footer.php"); ?>