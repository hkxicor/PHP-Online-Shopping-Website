<div class="slider">
	  <div class="callbacks_container">
	     <ul class="rslides" id="slider">
	         <li>
				 <div class="banner1">				  
					  <div class="banner-info">
					  <h3>Buy Gunine Products from your favorite Seller.</h3>
					  <p>Shopduct provides you flexiblity of choosing seller and price.</p>
					  </div>
				 </div>
	         </li>
	         <li>
				 <div class="banner2">
					 <div class="banner-info">
					 <h3>Get your Order within a Day.</h3>
					 <p>Shopduct Provide fastest delevery on all products.</p>
					 </div>
				 </div>
			 </li>
	         <li>
	             <div class="banner3">
	        	 <div class="banner-info">
	        	 <h3>Be sure and Pay when Product is Arrived.</h3>
	          	 <p>Shopduct Provide Cash On Delivery Option.</p>
				 </div>
				 </div>
	         </li>
	      </ul>
	  </div>
  </div>