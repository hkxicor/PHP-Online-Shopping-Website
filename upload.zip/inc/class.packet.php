<?php
class PACKET{
	private $db;
	private $order_id;
	private $packet_id;
	private $product_list;
	
	
}
?>