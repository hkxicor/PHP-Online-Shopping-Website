<?php
class USER{
	private $db;
	
	function __construct($db_con){
		$this->db=$db_con;
	}
	public function addAddress($name,$addline1,$addline2,$city,$pincode,$state,$landmark,$contact){
		try{
			$uid=$this->getId();
			$st = $this->db->prepare("INSERT INTO address(user_id,name,addline1,addline2,city,pincode,state,landmark,contact) values(:uid,:name,:addline1,:addline2,:city,:pincode,:state,:landmark,:contact)");
			$st->execute(array(':uid'=>$uid,':name'=>$name,':addline1'=>$addline1,':addline2'=>$addline2,':city'=>$city,':pincode'=>$pincode,':state'=>$state,':landmark'=>$landmark,':contact'=>$contact));
			return $st;
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function displayAddress( ){
		
		$uid=$this->getId();
		$st = $this->db->prepare("select * from address where user_id=:uid");
		$st->bindparam(':uid',$uid);
		$st->execute();
		$st->setFetchMode(PDO::FETCH_ASSOC);
	
		while($row = $st->fetch()){
			$add_id=$row['id'];
			$addline1=$row['addline1'];
			$addline2=$row['addline2'];
			$city=$row['city'];			
			$pincode=$row['pincode'];
			$state=$row['state'];
			$landmark=$row['landmark'];
			$contact=$row['contact'];
			$name = $row['name'];
			echo "<h4>".htmlspecialchars($name)."</h4><br>".htmlspecialchars($addline1).htmlspecialchars($addline2)." <br>".htmlspecialchars($city)."<br>".htmlspecialchars($pincode)." <br>".htmlspecialchars($state)." <br>".htmlspecialchars($contact)."<br><button onclick='delete_add(".htmlspecialchars($add_id).")'>Remove</button><hr>";	
		}
	
	}
	public function displayAddress2($fn1){
		
		$uid=$this->getId();
		$st = $this->db->prepare("select * from address where user_id=:uid");
		$st->bindparam(':uid',$uid);
		$st->execute();
		$st->setFetchMode(PDO::FETCH_ASSOC);
	
		while($row = $st->fetch()){
			$add_id=$row['id'];
			$name = $row['name'];
			$addline1=$row['addline1'];
			$addline2=$row['addline2'];
			$city=$row['city'];			
			$pincode=$row['pincode'];
			$state=$row['state'];
			$landmark=$row['landmark'];
			$contact=$row['contact'];
			$name = $row['name'];
			echo '<div  style="height:auto;border:1px grey dotted;text-align:center;padding:20px;">
				<input type="radio" name="'.htmlspecialchars($fn1).'" value="'.htmlspecialchars($add_id).'" required="required" />			
				<h3>'.htmlspecialchars($name).'</h3>
				<h4>'.htmlspecialchars($addline1)." ".htmlspecialchars($addline1)." ".htmlspecialchars($city)." ".htmlspecialchars($pincode).'</h4><br>
				'.htmlspecialchars($landmark).'<br>'.htmlspecialchars($contact).'
				</div><br>';
		}
		
	}
	public function displayAddress3($aId){
		
		$uid=$this->getId();
		$st = $this->db->prepare("select * from address where user_id=:uid");
		$st->bindparam(':uid',$uid);
		$st->execute();
		$st->setFetchMode(PDO::FETCH_ASSOC);
	
		while($row = $st->fetch()){
			$add_id=$row['id'];
			if(password_verify($add_id,$aId)){
			$name = $row['name'];
			$addline1=$row['addline1'];
			$addline2=$row['addline2'];
			$city=$row['city'];			
			$pincode=$row['pincode'];
			$state=$row['state'];
			$landmark=$row['landmark'];
			$contact=$row['contact'];
			$name = $row['name'];
			echo '<div  style="height:auto;text-align:center;padding:20px;">
				
				<h3>'.htmlspecialchars($name).'</h3>
				<h4>'.htmlspecialchars($addline1)." ".htmlspecialchars($addline1)." ".htmlspecialchars($city)." ".htmlspecialchars($pincode).'</h4><br>
				'.htmlspecialchars($landmark).'<br>'.htmlspecialchars($contact).'
				</div><br>';
			}
		}
		
	}
	
	public function isLogin(){
		if(isset($_SESSION['user_login'])){
			return true;
		}
		else{
			return false;
		}
		
	}
	public function getId(){
		if(isset($_SESSION['user_login'])){
			return $_SESSION['user_login'];
		}
		else{
			return 0;
		}
	}
	public function cartCount(){
		$getID="";
		try{
			if($this->isLogin()){
			$st = $this->db->prepare("select * from cart where user_id=:uid");
			$getID =$this->getId();
			$st->bindparam(':uid',$getID);
			$st->execute();
			return $st->rowCount();
			}
			else{
				return 0;
			}
			
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
			
	}
	public function getName(){
		try{
				$fname = "";
				if($_SESSION['user_login']){
					$id=$_SESSION['user_login'];
					$st = $this->db->prepare("select fname from users where user_id=:uid");
					$st->bindparam(':uid',$id);
					$st->execute();
					$row = $st->fetch(PDO::FETCH_ASSOC);
					if($st->rowCount() > 0){
						return  $row['fname'];
					}
				}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
			
	}
	public function getLName(){
		try{
				$fname = "";
				if($_SESSION['user_login']){
					$id=$_SESSION['user_login'];
					$st = $this->db->prepare("select lname from users where user_id=:uid");
					$st->bindparam(':uid',$id);
					$st->execute();
					$row = $st->fetch(PDO::FETCH_ASSOC);
					if($st->rowCount() > 0){
						return  $row['lname'];
					}
				}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
			
	}
	public function redirect($url){
		//header("Location:$url");
		echo '<script>window.location.href = "'.$url.'";</script>';
	}
	
	public function logout(){
		session_destroy();
		unset($SESSION['user_login']);
		return true;
	}
	
	public function login($email,$password){
			try{
				$st = $this->db->prepare("select * from users where user_email=:uemail");
				$st->bindparam(":uemail",$email);
				$st->execute();
				$userRow=$st->fetch(PDO::FETCH_ASSOC);
				if($st->rowCount() > 0){
					if(password_verify($password,$userRow['user_pass'])){
						$_SESSION['user_login'] = $userRow['user_id'];
						return true;
					}
					else{
						return false;
					}
				}
			}
			catch(PDOException $e ){
				echo $e->getMessage();
			}
			
	}
	
	
	public function register($email,$password,$mobile,$fname,$lname){
		try{
			//check for redundant email and mobile
			$st1 = $this->db->prepare("select * from users where user_email=:uemail OR mobile=:umobile");
			$st1->execute(array(':uemail'=>$email,':umobile'=>$mobile));
			//if rowcount is zero then ok
			if($st1->rowCount() == 0){
				$st2 = $this->db->prepare("insert into users(user_email,fname,lname,user_pass,mobile) values(:uemail,:fname,:lname,:upassword,:umobile)");
				$password_hash= password_hash($password,PASSWORD_DEFAULT);
				$st2->execute(array(':uemail'=>$email,':fname'=>$fname,':lname'=>$lname,':upassword'=>$password_hash,':umobile'=>$mobile));
				return $st2;
			}
			else{
				return false;
			}
			
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
	}
	public function updateDetails($fname,$lname){
		try{
			//check for redundant email and mobile
			$st1 = $this->db->prepare("update users set fname=:fn , lname=:ln where user_id=:uid");
			$uid = $this->getId();
			$st1->execute(array(':fn'=>$fname,':ln'=>$lname,':uid'=>$uid));
			//if rowcount is zero then ok
			return $st1;
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
	}
	public function decryptAddress($aId){
		try{
			$st = $this->db->prepare("select id from address where user_id=:uid");
			$uid = $this->getId();
			$st->execute(array(':uid'=>$uid));
			$st->setFetchMode(PDO::FETCH_ASSOC);
			while($row = $st->fetch()){
				if(password_verify($row['id'],$aId)){
					return $row['id'];
				}
			}
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
	}
	
	
	
}

?>