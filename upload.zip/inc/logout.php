<?php

include("./inc/header.php");

$user->logout();
$user->redirect("./index.php");

?>