<?php
session_start();
session_regenerate_id();

//need to protect this
$dbhost="localhost";
$dbuser="root";
$dbpassword="";
$dbname="shopduct_db";

try{
	$DB_con = new PDO("mysql:host={$dbhost};dbname={$dbname}",$dbuser,$dbpassword);
	$DB_con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}
catch(PDOExcetion $e){
	echo $e->getMessage();
}

include_once './inc/class.user.php';
include_once './inc/class.product.php';
include_once './inc/class.cart.php';
include_once './inc/class.dealer.php';

$user =  new USER($DB_con);
$cart = new CART($DB_con);

?>

