<?php
class CHECKOUT{
	private $db;
	private $coStep;
	 
	function __construct($db_con){
		$this->db = $db_con;
		if(isset($_SESSION['coStep'])){
			$this->coStep = $_SESSION['coStep'];
		}
		else{
			$_SESSION['coStep'] = 0;
		}
	}
	function setCoStep($step){
		if(($this->coStep+1) == $step){
			$this->coStep = $this->coStep +1;
			$_SESSION['coStep'] = $_SESSION['coStep'] +1;
		}
	}
	public function getCoStep(){
		return $this->coStep;
	}
	public function destroyCo(){
		unset($_SESSION['coStep']);
		$this->coStep = 0;
	}
	
	public function printVirtualBill($flag,$aId){
		
		echo '<div class="log" align="middle">			 
				<p>By placing your order , you agree to ShopDuct Privacy notice and conditions of use.</p>
				<br><h3 style="text-decoration:underline;">Product Description</h3><br>
				<div style="border:1px grey dotted;"> <br>
				<h4>Products Dived According to sellers</h4>';
				$user = new USER($this->db);
				$uid = $user->getId();
				$ggTotal = 0;
				$ggDel = 0;
				$st = $this->db->prepare("select distinct dealer_id from cart where user_id=:uid");
				$st->bindparam(':uid',$uid);
				$st->execute();
				$st->setFetchMode(PDO::FETCH_ASSOC);
				
				while($row = $st->fetch()){
					$did = $row['dealer_id'];
					$d = new DEALER($this->db,$did);
					echo '<div style="border:1px grey solid;width:90%;padding:10px;margin:10px;background-color:grey;color:white" class="shadow">
					<h2>'.$d->getShopName().'</h2><br><br>';
					
					$st2=$this->db->prepare("select * from cart where user_id = :uid AND dealer_id = :did");
					$st2->bindparam(':uid',$uid);
					$st2->bindparam(':did',$did);
					$st2->execute();
					$st2->setFetchMode(PDO::FETCH_ASSOC);
					$packetTotal = 0;
					while($row2 = $st2->fetch()){
						$cid = $row2['id'];
						$pid = $row2['product_id'];
						$qty = $row2['qty'];
						
						//now print the products
						$p = new PRODUCT($this->db,$pid);
						$pName = $p->getName();
						$dName = $d->getShopName();
						$price = $d->productPrice($pid);
						
						
							echo '<div class="cart-item-thumb" id="item" >
							<h3 ">'."Product Name: ".$pName.'</h3>
							<h6>in stock</h6><br>
							<h4 >'."Sold by: ".$dName.'</h4><br>
							<h4 > '."Cost: ".$price." &#215 ".$qty."=".$price*$qty."&#8377".' </h4><br></div>';
							$packetTotal = $packetTotal+$qty*$price;
							
					}
					
					$st3 = $this->db->prepare("select * from delevery_charge where dealer_id=:did");
					$st3->bindparam(':did',$did);
					$st3->execute();
					$st3->setFetchMode(PDO::FETCH_ASSOC);
					while($row3 = $st3->fetch()){
						 $Min = $row3['min'];
						 $Charge = $row3['charge'];
					}	
						$packetDel = $Charge;
						if($packetTotal < $Min){
							$packetDel = $Charge;
						}
						else{
							$packetDel = 0;
						}
					echo 'Packet total : '.$packetTotal.'₹ <br>Delevery Charge:'.$packetDel.'₹  <br><hr><span style="background-color:black;color:white;">Grand Total:'.($packetTotal+$packetDel).'₹</span>';
													$ggTotal+=$packetTotal;
													$ggDel=$ggDel+$packetDel;
						echo '</div>';
					
					
				}
				echo '</div>			
					<br><h3  style="background-color:grey;padding:10px;color:white">Order Summary</h3><hr>
			<div class="cart-item-thumb" style="height:auto;">
			<p>Order placed by :<h5>';
			 if($flag){
				 echo $user->getName()." ".$user->getLName();
			 }
			 
			echo '</h5></p>
			<p>Estimated Delivery:</p>
			<h4>';
			
				$date1 = strtotime("+2 day");
				$date2 = strtotime("+3 day");
			  echo "from ".date('M d, Y',$date1)." to ".date('M d, Y',$date2);
			  
			  echo '</h4>
			<h5>items cost: ';
				
				
						echo $ggTotal.'₹';
					
			
			echo '</h5>
			<h5>Delivery: ';
				
				echo $ggDel.'₹';
				
			
			echo '</h5>
			<h5>Order Total:';
				
					$gTotal=$ggTotal+$ggDel;
					echo $gTotal.'₹';
			   echo '
			</h5>
			 
				<h4 style="color:white;background-color:green;padding:20px;color:white">You have to pay ';
			
			echo $gTotal." &#8377";
			echo 
			'</h4></div>
			
			<br><h3 style="background-color:grey;padding:10px;color:white">Delivery address</h3><hr>
			<div class="cart-item-thumb" style="height:auto;">
			
			<p>';
				
					if($flag){
						$user->displayAddress3($aId);
					}					
				
			echo '</p>
			
			</div>
			
			
			<br><h3 style="background-color:grey;padding:10px;color:white" >Payment information</h3><hr>
			<div style="height:auto">
			<h4>Payment method:Cash on delivery.</h4><br>
			<h4>Payment Address : Same as Shipping Address.</h4><br>
			<h4>Payment:'.$gTotal.'&#8377</h4>';
			echo '</div>
				<hr>
				<p> When you order is placed , well send your an e-mail message acknowledging receipt of your order. </p>';
				echo '
				<form method="post" action="po.php">
				<input type="hidden" name="aId" value="'.$aId.'" />
				<input type="submit" class="cs-button" align="middle" value=" Placr your order" >
				</form>';

				
					
		echo '</div>';
		
		
		
		
	}
	public function createOrder($uid,$aId,$product_qty,$packet_qty,$product_cost,$delevery_cost){
		try{
			$st = $this->db->prepare("insert into orders(user_id,order_date,address_id,product_qty,packet_qty,product_cost,delevery_cost) values(:uid,now(),:aid,:pqty,:packqty,:pcost,:dcost)");
			$st->execute(array(':uid'=>$uid,':aid'=>$aId,':pqty'=>$product_qty,':packqty'=>$packet_qty,':pcost'=>$product_cost,':dcost'=>$delevery_cost));
		
			return $this->db->lastInsertId();
			
			
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
	}
	public function createPacket($order_id,$dealer_id,$packet_total,$packet_del){
		try{
			$st = $this->db->prepare("insert into packet(order_id,dealer_id,packet_total,packet_del) value(:oid,:did,:ptotal,:pdel)");
			$order_id = (int) $order_id;
			$dealer_id = (int)$dealer_id;
			$packet_total = (int)$packet_total;
			$packet_del = (int)$packet_del;
			$st->execute(array(':oid'=>$order_id,':did'=>$dealer_id,':ptotal'=>$packet_total,':pdel'=>$packet_del));
			
			
			return $this->db->lastInsertId();
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
	}
	public function insertPacketDetails($packet_id,$product_id,$price,$qty){
		try{
			$st = $this->db->prepare("insert into packet_desc(packet_id,product_id,price,qty) value(:packetid,:pid,:price,:qty)");			
			
			$st->execute(array(':packetid'=>$packet_id,':pid'=>$product_id,':price'=>$price,':qty'=>$qty));
			 
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
	}
}


	