 <script>
 
	function show_result(id){
		
		window.location.href ="result.php?id="+id;		
		}	
	 
 </script>
<div class="items">

	 <div class="container">
	 <h4 class="top" >New Arrived Books</h4>
		  
		 
	 </div>
</div>

<div class="offers">
	 <div class="container">
	 <h3>Computer Science Books</h3>
	 <div class="offer-grids">
			
	 </div>
	 </div>
</div>
<div class="offers">
	 <div class="container">
	 <h3>Electronics and Communication</h3>
	 <div class="offer-grids">
			
	 </div>
	 </div>
</div>
<div class="offers">
	 <div class="container">
	 <h3>Electrical Engineering Books</h3>
	 <div class="offer-grids">
			
	 </div>
	 </div>
</div>