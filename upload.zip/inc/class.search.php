<?php

class SEARCH{
	private $db;
	
	function __construct($db_con){
		$this->db = $db_con;
	}
	
	public function search($q,$cat){
		$words = $this->breakString($q);
		$productList= array();
		$count = 0;
		
		foreach($words as $w){
			$w = "%".$w."%";
			try{
				$st=$this->db->prepare("select product_id from product_list where keyword like :w");
				$st->bindparam(':w',$w,PDO::PARAM_STR);
				$st->execute();
				if($st->rowCount()>0){
					$productList = array_merge($productList,$st->fetchAll());
					$count += $st->rowCount();
				}
			}
			catch(PODException $e){
				echo $e->getMessage();
			}
		}
		var_dump($productList);
		return $productList;
		
	}
	
	private function breakString($q){
		return explode(" ",$q);
	}
	private function searchCount($q,$cat){
		$words = $this->breakString($q);
		$count = 0;
		
		foreach($words as $w){
			$w = "%".$w."%";
			try{
				$st=$this->db->prepare("select product_id from product_list where keyword like :w");
				$st->bindparam(':w',$w,PDO::PARAM_STR);
				$st->execute();
				if($st->rowCount()>0){
					$count += $st->rowCount();
				}
			}
			catch(PODException $e){
				echo $e->getMessage();
			}
		}
		return $count;
	}
	public function printProducts($pL,$q,$cat){
		$count = $this->searchCount($q,$cat);
		if($count == 0){
			echo "Sorry ... item not found .<br> TRY AGAIN";
		}
		for($i = 0;$i < $count ; $i++){
			$pid = $pL[0][$i];
			$p = new PRODUCT($this->db,$pid);
			
			echo '<div id="box-6"  onclick="show_result('.$p->getId().')" class="col-md-2 btm-grid">
					 <a>
						<img class="fix1"  src="'.$p->getimage().'" alt=""/>
						<h4>'.$p->getName().'</h4>
						<span style="display:none;" class="caption scale-caption">
					</a>
				 </div>';
			//delete($p);
		}
	}
}

?>