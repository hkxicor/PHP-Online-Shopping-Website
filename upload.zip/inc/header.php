<?php // error_reporting(E_ERROR|E_PARSE); ?>
<?php include_once './inc/db.php'; ?>
<!DOCTYPE html>
<html>
<head>
<title>Buy Online Books and Many more @ Shopduct.com</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/docs.min.css" rel="stylesheet">
<!-- Custom Theme files -->
<!--theme style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<script src="js/jquery.min.js"></script>
<script src="js/nav.js" type="text/javascript"></script>
<!--//theme style-->

<!-- Sweet Alert -->
<script src="dist/sweetalert.min.js">
</script> <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Buy Online Producs Electronics Mobile, Laptop, Charger, Acceseries, Books Engineering, Computer Science,
Electronics and communication , mechanical , civil and many more
" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- start menu -->
<script src="js/simpleCart.min.js"> </script>
<style type="text/css">

.dropdown.dropdown-lg .dropdown-menu {
    margin-top: -1px;
    padding: 6px 20px;
}
.input-group-btn .btn-group {
    display: flex !important;
}
.btn-group .btn {
    border-radius: 0;
    margin-left: -1px;
}
.btn-group .btn:last-child {
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
}
.btn-group .form-horizontal .btn[type="submit"] {
  border-top-left-radius: 4px;
  border-bottom-left-radius: 4px;
}
.form-horizontal .form-group {
    margin-left: 0;
    margin-right: 0;
}
.form-group .form-control:last-child {
    border-top-left-radius: 4px;
    border-bottom-left-radius: 4px;
}
</style>
<!-- start menu -->
<link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="js/memenu.js"></script>
<script>$(document).ready(function(){$(".memenu").memenu();});</script>	
<!-- /start menu -->
</head>
<body> 
<!--header-->	
<script src="js/responsiveslides.min.js"></script>
<script>  
    $(function () {
      $("#slider").responsiveSlides({
      	auto: true,
      	nav: true,
      	speed: 500,
        namespace: "callbacks",
        pager: false,
      });
    });
  </script>
  
<div class="header-top">
	 <div class="header-bottom">			
				<div class="logo"  >
				<a href="index.php" ><img style="width:300px;padding:15px;" src="./img/ICON3.png" alt="" ></a>	
				<!--	<h1><a href="index.php"></a></h1> -->					
				</div>
			 <!---->		 
			 <div class="top-nav">
				<ul class="memenu skyblue"><!--<li class="active"><a href="index.php">Home</a></li> -->
					<li class="grid"><a href="#">Books</a>
						<div class="mepanel">
							<div class="row">
								<div class="col1 me-one">
									<h4>Engineering</h4>
									<ul>
										<li><a href="./search.php?q=&cat=all">New Arrivals</a></li>
										<li><a href="./search.php?q=&cat=cs">Computer Engineering</a></li>
										<li><a href="./search.php?q=&cat=ec">Electronics and Communication</a></li>
										<li><a href="./search.php?q=&cat=mech">Mechanical Engineering</a></li>
										<li><a href="./search.php?q=&cat=civil">Civil Engineering</a></li>
										<li><a href="./search.php?q=&cat=ee">Electrical Engineerign</a></li>
										<li><a href="./search.php?q=&cat=eic">Electronics instrumnetal Control</a></li>
										<li><a href="./search.php?q=&cat=all">All Books</a></li>
									</ul>
								</div>
								<div class="col1 me-one">
									<h4>Solved Papers</h4>
									<ul>
										<li><a href="./search.php?q=solved paper&cat=all">N.K Series Solved Papers</a></li>
										
										
									</ul>	
								</div>
							<!--	<div class="col1 me-one">
									<h4>Popular Brands</h4>
									<ul>
										<li><a href="product.php">Genius Publication</a></li>
										<li><a href="product.php">Neel Kanth Publication</a></li>
										<li><a href="product.php">Ashirwad Publication</a></li>
										<li><a href="product.php">Pearson</a></li>
										<li><a href="product.php">Tata Mc.Graw Hill</a></li>
									</ul>	
								</div> -->
							</div>
						</div>
					</li>
					<li class="grid"><a href="#">Electronics</a>
						<div class="mepanel">
							<div class="row">
								
								<div class="col1 me-one">
									<h4>Mobile & Tablets</h4>
									<ul>
										<li><a href="./search.php?q=&cat=all">All Mobile Phones</a></li>
										<li><a href="./search.php?q=&cat=cs">Featured Mobile Phones</a></li>
										<li><a href="./search.php?q=&cat=ec">Smart Phones</a></li>
										<li><a href="./search.php?q=&cat=mech">Tablets</a></li>
										<li><a href="./search.php?q=&cat=civil">ipad</a></li>
									</ul>
									
								</div>
								<div class="col1 me-one">
									<h4>Computer And Accesories</h4>
									<ul>
										<li><a href="./search.php?q=&cat=all">New Arrivals</a></li>
										<li><a href="./search.php?q=&cat=cs">Desktop Computer</a></li>
										<li><a href="./search.php?q=&cat=ec">Laptop and Notebook</a></li>
										<li><a href="./search.php?q=&cat=mech">Mac Book</a></li>
									</ul>
									
								</div>
								<div class="col1 me-one">
								<h4>Gaming</h4>
									<ul>
										<li><a href="./search.php?q=&cat=all">All Gaming</a></li>
										<li><a href="./search.php?q=&cat=cs">Console</a></li>
										<li><a href="./search.php?q=&cat=ec">Gaming Titles</a></li>
										<li><a href="./search.php?q=&cat=mech">Gaming Accessories</a></li>
									</ul>
								</div>
							</div>
						</div>
					</li>
					<?php 
								
					$opt1="";
					$opt2="";
					$opt3="";
					$title="";
					$link_opt1="";
					$link_opt2="";
					$link_opt3="";
					$link_title="";
					
					if($user->isLogin()){
						$title=$user->getName();
						$link_title="./account.php";
						$opt1='My Account';
						$link_opt1="./user_account.php";
						$opt2="My orders";
					$link_opt2="./orders.php";
					$opt3="Logout";
					$link_opt3="./logout.php";
								
					}
					else {
						$title="Account";
						$link_title="./login.php";
						$opt1="Login";
						$link_opt1="./login.php";
						$opt2="Register";
						$link_opt2="./register.php";
						$opt3="Forgot Password";
						$link_opt3="./forgot_password.php";					
					} 
					
				
				
				?>

					
					<li class="grid"><a href="<?php echo htmlspecialchars($link_title); ?>"><?php echo htmlspecialchars($title); ?></a>
						<div class="mepanel float_right">
							<div class="row float_right" >
								
								<div class="me-one ">
									<h4><a href="<?php  echo htmlspecialchars($link_opt1); ?>"><?php echo htmlspecialchars($opt1); ?></a></h4>
								</div><br>
								<div class="me-one ">
									<h4><a href="<?php echo htmlspecialchars($link_opt2); ?>"><?php echo htmlspecialchars($opt2); ?></a></h4>
								</div><br>
								<div class="me-one ">
									<h4><a href="<?php echo htmlspecialchars($link_opt3); ?>"><?php echo htmlspecialchars($opt3); ?></a></h4>
								</div>
								
							</div>
						</div>
					</li>
					
				</ul>				
			 </div>
			 <!---->
			 <div class="cart box_1">
				 <a href="cart.php">
					<div class="total">
					<span id="cart_count">(<?php 
						$c = new CART($DB_con);
						echo $c->cartCount($user->isLogin());
					?>)</div>
					<img style="background-color:crimson;width:50px;padding:10px;padding-right:15px;" src="./images/cart.png" alt="" >
					
				</a>
				
			 	<div class="clearfix"> </div>
			 </div>
			 <div class="cart box_1 search-but" > 
			<img style="width:40px;margin-top:3px;" src="./images/search.png" alt="" >	
			 	
			 </div>
			 
			 
			 
			 
			 </div>
			<div class="clearfix"> </div>
</div>
<?php
include_once './inc/class.csrf.php';
$csrf = new CSRF();

//generate token id and validate 

$token_id = $csrf->get_token_id();
$token_value = $csrf->get_token($token_id);
$form_names = $csrf->form_names(array('cat','search_bar'),false);

if(isset($_POST[$form_names['cat']],$_POST[$form_names['search_bar']])){
	if($csrf->check_valid('post')){
		$cat = $_POST[$form_names['cat']];
		$q = $_POST[$form_names['search_bar']];
		
		//from start 
		
			//filter 
				$cat = strip_tags($cat);
				$q = strip_tags($q);
				$cat =trim($cat);
				$q = trim($q);
		
			//validate
				$cat = (strlen($cat)<10) ? $cat : "";
				$q = (strlen($q)<16 ) ? $q : "";
		
			//implement
				$string = "";
				$string = "search.php?q=".$q."&cat=".$cat;
				$user->redirect($string);
				
		//form end
	}
	//regenerate new random values for the form.
	$form_names = $csrf->form_names(array('cat','search_bar'),true);
}

//need to fix this 

?>
<form action="#" method="POST">
<div class="search-wrap" align="middle" >
	<div id="search_block" class="panel-body" >
    <form role="form" class="form-horizontal" method="post" action="#">
	<input type="hidden" name="<?php echo $token_id ?>" value="<?php echo htmlspecialchars($token_value); ?>" />
        <div class="form-group">
              <div class="col-xs-10 col-sm-8 col-md-2" id="filters">
                <select class="form-control"  name="<?php echo $form_names['cat']; ?>" />
                    <option selected="selected" value="all" >All Category</option>
                    <option value="cs">Computer Science </option>
							<option value="ece">Electronics and Communication Engineering</option>
							<option value="mech">Mechanical Engineering</option>
							<option value="ee">Electrical Engineering</option>
							<option value="civil">Civil Engineering</option>
							<option value="eic">Electronic Instrument Control</option>
                </select>
            </div>
            <div class="col-xs-10 col-sm-8 col-md-4">
                <input type="text" name="<?php echo  $form_names['search_bar']; ?>" placeholder="Enter Search for Books Auther and Publication" value=""  id="v_search" class="form-control">
            </div>
            <div class="button-group col-xs-10 col-xs-offset-0 col-sm-8 col-sm-offset-2 col-md-3 col-md-offset-0">
                <button class="btn btn-primary" value="search" type="submit" name="search">Search</button>
                
            </div>
        </div>
        
    </form>
</div>
</div>
</form>

<div class="navigation">
	<div class="current-loc">Current Location : Ajmer</div>
	
</div>
 <script type="text/javascript" >
	$('.search-but').click(function(){
			$('.search-wrap').slideToggle();		
		})

</script>