<?php
class CART{
	private $db;
	private $user_id;
	function __construct($db_con){
		$this->db = $db_con;
		if(isset($_SESSION['user_login'])){
			$this->user_id = $_SESSION['user_login'];
		}
		else{
			$this->user_id = 0;
		}
	}
	
	public function cartCount($islogin){
		try{
			if($islogin){
			$st = $this->db->prepare("select * from cart where user_id=:uid");
			$uid = $this->user_id;
			$st->bindparam(':uid',$uid);
			$st->execute();
			return $st->rowCount();
			}
			else{
				return 0;
			}
			
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function displayProductAccordingToSeller(){
		try{
			$st = $this->db->prepare("select distinct dealer_id from cart where user_id=:uid");
			$uid = $this->user_id;
			$st->bindparam(':uid',$uid);
			$st->execute();
			$st->setFetchMode(PDO::FETCH_ASSOC);
			while($row = $st->fetch()){
					$dealer_id = $row['dealer_id'];
					include_once './inc/class.dealer.php';
					$d = new DEALER($this->db,$dealer_id);
					//
					echo '<div style="border:1px grey solid;width:90%;padding:10px;margin:10px;background-color:grey;color:white" class="shadow">';
					echo '<h2>'.$d->getShopName().'</h2><br><br>';
					
					$st1 = $this->db->prepare("select * from cart where user_id=:uid and dealer_id=:did");
					$st1->bindparam(':uid',$uid);
					$st1->bindparam(':did',$dealer_id);
					$st1->execute();
					$st1->setFetchMode(PDO::FETCH_ASSOC);
					$packet_total=0;								
					while($row1 = $st1->fetch()){
						$cid = $row1['id'];
						$product_id = $row1['product_id'];
						$qty = $row1['qty'];
						$price = $d->productPrice($product_id);
						include_once './inc/class.product.php';
						$p = new PRODUCT($this->db,$product_id);
						
						
						echo '<div class="cart-item-thumb" id="item" >
						<h3 ">'."Product Name: ".$p->getName().'</h3>
						<h6>in stock</h6><br>
						<h4 >'."Sold by: ".$d->getShopName().'</h4><br>
						<h4 > '."Cost: ".$price." &#215 ".$qty."=".$price*$qty."&#8377".' </h4><br>
						</div>';
						$packet_total = $packet_total+$qty*$price;
					}
					
			}
			
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function getCartId($uid,$pid,$did){
		try{
			$st = $this->db->prepare("SELECT id FROM cart WHERE user_id=:uid AND product_id=:pid AND dealer_id=:did");
			$st->bindparam(':uid',$uid);
			$st->bindparam(':pid',$pid);
			$st->bindparam(':did',$did);
			$st->execute();
			$st->setFetchMode(PDO::FETCH_ASSOC);
			while($row = $st->fetch()){
					return $row['id'];
			}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function addToCart($pid,$did){		
		try{
			if($this->countProductPresentInCart($pid,$did) == 0){
				//product is not present in cart
				$st = $this->db->prepare("INSERT INTO cart(user_id,product_id,qty,dealer_id) values(:uid,:pid,:qty,:did)");
				$uid = $this->user_id;
				$qty = 1;
				$st->bindparam(':uid',$uid);
				$st->bindparam(':pid',$pid);
				$st->bindparam(':did',$did);
				$st->bindparam(':qty',$qty);
				$st->execute();
				return $st;
			}
			else{
				//product is present in cart INCREMENT
				$st = $this->db->prepare("UPDATE cart SET qty=qty+1 WHERE product_id=:pid AND dealer_id=:did AND user_id=:uid");
				$uid = $this->user_id;
				$st->bindparam(':uid',$uid);
				$st->bindparam(':pid',$pid);
				$st->bindparam(':did',$did);
				$st->execute();
				return $st;
			}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function deleteProduct($cid){
		
		try{
			$st = $this->db->prepare("DELETE FROM cart WHERE id=:cid and user_id=:uid");
			$uid = $this->user_id;
			$st->bindparam(':cid',$cid);
			$st->bindparam(':uid',$uid);
			return $st->execute();
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
		
	}
	public function cartUser($cid){
		try{
			$st = $this->db->prepare("SELECT user_id FROM cart WHERE id=:cid");
			$st->bindparam(':cid',$cid);
			$st->execute();
			$st->setFetchMode(PDO::FETCH_ASSOC);
			while($row = $st->fetch()){
					return $row['user_id'];
			}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function countProductPresentInCart($pid,$did){
		try{
			$st = $this->db->prepare("SELECT * FROM cart WHERE product_id=:pid AND dealer_id=:did AND user_id=:uid");
			$uid = $this->user_id;
			$st->bindparam(':uid',$uid);
			$st->bindparam(':pid',$pid);
			$st->bindparam(':did',$did);
			$st->execute();
			return $st->rowCount();
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function countProductQtyInCart($pid,$did){
		try{
			$st = $this->db->prepare("SELECT * FROM cart WHERE product_id=:pid AND dealer_id=:did AND user_id=:uid");
			$uid = $this->user_id;
			$st->bindparam(':uid',$uid);
			$st->bindparam(':pid',$pid);
			$st->bindparam(':did',$did);
			$st->execute();
			$st->setFetchMode(PDO::FETCH_ASSOC);
			while($row = $st->fetch()){
				return $row['qty'];
			}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function cartProductQtyModify($cid,$act){
		if( $act == 1){
			//inc
			try{
				$st = $this->db->prepare("UPDATE cart SET qty=qty+1 WHERE id=:cid AND user_id=:uid");
				$uid = $this->user_id;
				$st->bindparam(':cid',$cid);
				$st->bindparam(':uid',$uid);
				return $st->execute();
			}
			catch(PDOException $e ){
					echo $e->getMessage();
				}
		}
		elseif($act==2){
			//dec
			try{
				$st = $this->db->prepare("UPDATE cart SET qty=qty-1 WHERE id=:cid AND user_id=:uid");
				$uid = $this->user_id;
				$st->bindparam(':cid',$cid);
				$st->bindparam(':uid',$uid);
				return $st->execute();
			}
			catch(PDOException $e ){
					echo $e->getMessage();
				}
		}
		else{
			return false;
		}
	}
	public function cartProductQty($cid){
		try{
			$st = $this->db->prepare("SELECT qty FROM cart WHERE id=:cid");
			$st->bindparam(':cid',$cid);
			$st->execute();
			$st->setFetchMode(PDO::FETCH_ASSOC);
			while($row = $st->fetch()){
				return $row['qty'];
			}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function cartProductPrint(){
		try{
			$user_id = $this->user_id;
			$st = $this->db->prepare("select distinct dealer_id from cart where user_id=:uid");
			$st->bindparam(':uid',$user_id);
			$st->execute();
			$st->setFetchMode(PDO::FETCH_ASSOC);
			$TotalCost = 0;
			while($row = $st->fetch()){
				$packetTotal = 0;
				$did = $row['dealer_id'];
				$st2 = $this->db->prepare("select id,product_id,qty from cart where user_id=:uid AND dealer_id=:did ");
				$st2->bindparam(':uid',$user_id);
				$st2->bindparam(':did',$did);
				$st2->execute();
				$st->setFetchMode(PDO::FETCH_ASSOC);
				while($row2 = $st2->fetch()){
					$pid = $row2['product_id'];
					$qty = $row2['qty'];
					$cid = $row2['id'];
					$p = new PRODUCT($this->db,$pid);
					$d = new DEALER($this->db,$did);
					$price = $d->productPrice($pid);
					echo "Seller : <h3>".$d->getShopName()." ".$d->getShopCity()."</h3><hr>";
					$TotalCost += $price*$qty;
					$packetTotal += $price*$qty;
					
					echo '<div class="cart-header">
						<span class="close1 del_button"   onclick="deleteProduct('.$cid.')" > </span>
						<div class="cart-sec simpleCart_shelfItem">
						<div class="cart-item cyc">
						<img src="'.$p->getimage().'" class="img-responsive" alt=""/>
						
					  </div>
					   <div class="cart-item-info">
						    <h3><a href="single.html">'.$p->getName().'</a>
						  
						    </h3>
							<ul class="qty">
								<li><p>Price : '.$price.'₹</p></li>
								<li><p>Qty : '.$qty.'</p></li>
							</ul><br>
							<ul class="qty">
								<li><p><button onclick="InDecProduct('.$cid.',1)" >Quantity+</button></p></li>
								<li><p><button onclick="InDecProduct('.$cid.',2)" >Quantity-</button></p></li>
							</ul>
							<div class="delivery">
								 <p>Product Cost : '.$qty.' &#10060 '.$price.' = '.($price*$qty).'₹</p>
								 <span>Seller: '.$d->getShopName().','.$d->getShopCity().'</span>
								 <div class="clearfix"></div>
							</div>
								
					   </div>
					   
					   <div class="clearfix"></div>
					   
				  </div>
				  
			 </div>
				
								
				
			 ';
			 
			 echo "Packet Total :".$packetTotal."<hr>";
				}
				
			}
			echo '</div>
		<div class="clearfix"> </div>
		<div class="col-md-3 cart-total">
			<a class="continue" href="index.php">Continue Shopping</a>
			<div class="price-details">
				<h3>Price Details</h3>
				<span>Total</span>
				<span class="total1">'.$TotalCost.' &#8377</span>
				<span>Discount</span>
				<span class="total1"> 0%</span>
				
				<span class="total1"></span>
				<div class="clearfix"></div>				 
			</div>	
			<ul class="total_price">
			   <li class="last_price"> <h4>TOTAL</h4></li>	
			   <li class="last_price"><span>'.$TotalCost.' &#8377</span></li>			   
			</ul> 
			<div class="clearfix"></div>
			<div class="clearfix"></div>';
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
		
	}
	
	public function allProductQtyCount(){
		try{
			$st = $this->db->prepare("SELECT * FROM cart WHERE user_id=:uid");
			$uid = $this->user_id;
			$st->bindparam(':uid',$uid);
			$st->execute();
			$st->setFetchMode(PDO::FETCH_ASSOC);
			$allProductQtyCount = 0;
			while($row = $st->fetch()){
				$allProductQtyCount += $row['qty'];
			}
			return $allProductQtyCount;
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	
	public function allPacketCount(){
		try{
			$st = $this->db->prepare("SELECT distinct dealer_id FROM cart WHERE user_id=:uid");
			$uid = $this->user_id;
			$st->bindparam(':uid',$uid);
			$st->execute();
			return $st->rowCount();
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function allCartCost(){
		try{
			$st = $this->db->prepare("select product_id,dealer_id,qty from cart where user_id= :uid");
			$uid = $this->user_id;
			$st->bindparam(':uid',$uid);
			$st->execute();
			$st->setFetchMode(PDO::FETCH_ASSOC);
			$allCartCost = 0;
			while($row = $st->fetch()){
				include_once './inc/class.dealer.php';
				$d = new DEALER($this->db,$row['dealer_id']);
				$price = $d->productPrice($row['product_id']);
				$qty = $row['qty'];	
				$allCartCost  += $price*$qty; 
			}
			return $allCartCost;
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	private function dealerCartCost($did){
		try{
			$st = $this->db->prepare("select product_id,qty from cart where user_id= :uid AND dealer_id=:did");
			$uid = $this->user_id;
			$st->bindparam(':uid',$uid);
			$st->bindparam(':did',$did);
			$st->execute();
			$st->setFetchMode(PDO::FETCH_ASSOC);
			$cartCost = 0;
			while($row = $st->fetch()){
				include_once './inc/class.dealer.php';
				$d = new DEALER($this->db,$did);
				$price = $d->productPrice($row['product_id']);
				$qty = $row['qty'];	
				$cartCost  += $price*$qty; 
			}
			return $cartCost;
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function allCartDeleveryCost(){
		try{
			$st = $this->db->prepare("select product_id,dealer_id,qty from cart where user_id= :uid");
			$uid = $this->user_id;
			$st->bindparam(':uid',$uid);
			$st->execute();
			$st->setFetchMode(PDO::FETCH_ASSOC);
			$allCartDeleveryCost = 0;
			while($row = $st->fetch()){
				include_once './inc/class.dealer.php';
				$d = new DEALER($this->db,$row['dealer_id']);
				$did = $row['dealer_id'];
				
					$st3 = $this->db->prepare("select * from delevery_charge where dealer_id=:did");
					$st3->bindparam(':did',$did);
					$st3->execute();
					$st3->setFetchMode(PDO::FETCH_ASSOC);
					while($row3 = $st3->fetch()){
						 $min = $row3['min'];
						 $charge = $row3['charge'];
					}
					$cost = $this->dealerCartCost($did);
					if($cost < $min ){
						$allCartDeleveryCost +=  $charge;
					}
					
			}
			return $allCartDeleveryCost;
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
	}
	public function getAllDealersInCart(){
		try{
			$st = $this->db->prepare("SELECT distinct dealer_id FROM cart WHERE user_id=:uid");
			$uid = $this->user_id;
			$st->bindparam(':uid',$uid);
			$st->execute();
			return $st->fetchAll();
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
	}
	public function getPacketTotal($did){
		try{
			$st = $this->db->prepare("select * from cart where user_id= :uid AND dealer_id=:did");
			$uid = $this->user_id;
			$st->bindparam(':uid',$uid);
			$did = (int)$did;
			$st->bindparam(':did',$did);
			
			$st->execute();
			$st->setFetchMode(PDO::FETCH_ASSOC);
			
			include_once './inc/class.dealer.php';
			$d = new DEALER($this->db,$did);
			
			 $getPacketTotal = 0;
			while($row = $st->fetch()){
				$price = $d->productPrice($row['product_id']);
				$qty = $row['qty'];	
				$getPacketTotal  += $price*$qty; 
			}
			return $getPacketTotal;
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function getPacketDel($did){
		try{
			$st = $this->db->prepare("select * from cart where user_id=:uid AND dealer_id=:did");
			$uid = $this->user_id;
			$st->bindparam(':uid',$uid);
			$did = (int)$did;
			$st->bindparam(':did',$did);
			$st->execute();
			$st->setFetchMode(PDO::FETCH_ASSOC);
			$getPacketDel = 0;
			while($row = $st->fetch()){
				include_once './inc/class.dealer.php';
				$d = new DEALER($this->db,$did);
				
				
					$st3 = $this->db->prepare("select * from delevery_charge where dealer_id=:did");
					$st3->bindparam(':did',$did);
					$st3->execute();
					$st3->setFetchMode(PDO::FETCH_ASSOC);
					while($row3 = $st3->fetch()){
						 $min = $row3['min'];
						 $charge = $row3['charge'];
					}
					$cost = $this->dealerCartCost($did);
					if($cost < $min ){
						$getPacketDel +=  $charge;
					}
					
			}
			return $getPacketDel;
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
	}
	public function allProductsInPacket($dealer_id){
		try{
			$st = $this->db->prepare("select product_id from cart where user_id=:uid AND dealer_id=:did");
			$dealer_id =(int)$dealer_id;
			$st->execute(array(':uid'=>$this->user_id,':did'=>$dealer_id));
			return $st->fetchAll();
		}
		catch(PDOException $e){
			$e->getMessage();
		}
	}
	public function countProductInPacket($dealer_id){
		try{
			$st = $this->db->prepare("select * from cart where user_id=:uid AND dealer_id=:did");
			$dealer_id =(int)$dealer_id;
			$st->execute(array(':uid'=>$this->user_id,':did'=>$dealer_id));
			return $st->rowCount();
		}
		catch(PDOException $e){
			$e->getMessage();
		}
	}
	public function clearCart(){
		try{
			$st = $this->db->prepare("delete from cart where user_id=:uid");
			$st->execute(array(':uid'=>$this->user_id));
			return $st;
		}
		catch(PDOException $e){
			$e->getMessage();
		}
	}
}
?>