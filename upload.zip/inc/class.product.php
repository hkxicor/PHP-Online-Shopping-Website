<?php

class PRODUCT{
	private $db;
	private $product_id;
	private $seller_id;

	function __construct($db_con,$pid){
		$this->db= $db_con;
		$this->product_id = $pid;
		//$this->product_id = ($this->isValid())?$pid:0000000000;
	}
	public function getId(){
		return $this->product_id;
	}
	public function isValid(){
		try{
			$st = $this->db->prepare("select * from product_list where product_id=:pid");
			$st->bindparam(':pid',$this->product_id);
			$st->execute();
			$userRow=$st->fetch(PDO::FETCH_ASSOC);
			if($st->rowCount() == 0){
					return false;
				}
			else{
				return true;
			}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function setSid($pid){
		$this->$seller_id=$sid;
	}
	public function getName(){
		try{
			$st = $this->db->prepare("select product_name from product_list where product_id=:pid");
			$st->bindparam(':pid',$this->product_id);
			$st->execute();
			$userRow=$st->fetch(PDO::FETCH_ASSOC);
			if($st->rowCount() > 0){
					return $userRow['product_name'];
				}
			else{
				return "Empty_Product";
			}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function getImage(){
		try{
			$st = $this->db->prepare("select image from product_list where product_id=:pid");
			$st->bindparam(':pid',$this->product_id);
			$st->execute();
			$userRow=$st->fetch(PDO::FETCH_ASSOC);
			if($st->rowCount() > 0){
					return $userRow['image'];
				}
			else{
				return '';
			}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
			
	}
	public function getMrp(){
		try{
			$st = $this->db->prepare("select mrp from product_list where product_id=:pid");
			$st->bindparam(':pid',$this->product_id);
			$st->execute();
			$userRow=$st->fetch(PDO::FETCH_ASSOC);
			if($st->rowCount() > 0){
					return $userRow['mrp'];
				}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	/*public function getSellingPrice(){
		try{
			$st = $this->db->prepare("select selling_price from seller_product where product_id=:pid AND seller_id=:sid");
			$st->bindparam(':pid',$this->$product_id);
			$st->bindparam(':sid',$this->$seller_id);
			$st->execute();
			$userRow=$st->fetch(PDO::FETCH_ASSOC);
			if($st->rowCount() > 0){
					return $userRow['selling_price'];
				}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}*/
	public function getTable(){
		 return "t".mb_substr($this->product_id,0,4);
	}
	public function getAttr(){
		$temp = "";
		$attr_str="";
		try{
			$st = $this->db->prepare("select attr from table_list where table_name=:tname");
			$getTable = $this->getTable();
			$st->bindparam(':tname',$getTable);
			$st->execute();
			$userRow=$st->fetch(PDO::FETCH_ASSOC);
			if($st->rowCount() > 0){
					$attr_str=$userRow['attr'];
				}
			//new break the string using the comma
			return $temp = explode(",",$attr_str);
				
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	
	public function displayProuductDetails(){
	$OutputString = '<table  class="table table-bordered"><thead><tr><th>Attribute</th><th>Details</th></tr></thead>';
		$attr_list = $this->getAttr();
		
		foreach($attr_list as $Attr){
			$OutputString = $OutputString.'<th>'.$Attr.'</th><th>'.$this->attrDetails($Attr).'</th></tr>';
		}
		echo $OutputString = $OutputString.'</table>';
	}
	
	private function attrDetails($Attr){
		
		try{
			$query = "select ".$Attr." from ".$this->getTable()." where product_id=:pid";
			$st = $this->db->prepare($query);
			$st->bindparam(':pid',$this->product_id);
			$st->execute();
			$userRow=$st->fetch(PDO::FETCH_ASSOC);
			if($st->rowCount() > 0){
					return $userRow[$Attr];
				}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	
	public function displayDealers(){
		
		try{
			
			$st = $this->db->prepare("select dealer_id from dealer_product where product_id=:pid");
			$st->bindparam(':pid',$this->product_id);
			$st->execute();
			$st->setFetchMode(PDO::FETCH_ASSOC);
			while($row = $st->fetch()){
				$dealer_id = $row['dealer_id'];
				$dealer = new DEALER($this->db,$dealer_id);
				$shop_name = $dealer->getShopname();
				$product_price = $dealer->productPrice($this->product_id);
				//now print the table 
				echo '<tr><th>'.$shop_name.'</th><th>'.$product_price.'₹</th><th><button class="btn btn-default" onclick="addToCart('.$this->product_id.','.$dealer_id.')" > ADD TO CART</button> </th><tr/>';
			}
			echo '</table>';
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	
}

?>