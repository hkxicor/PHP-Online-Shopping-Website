<div class="footer">
	 <div class="container">
		 <div class="footer-grids">
			 <div class="col-md-3 about-us">
				 <h3>About Shopduct</h3>
				 <p>Shopduct Provides both free e-Platform to retailers for sell and more transparent options to customer in minimum delivery time.</p>
			 </div>

				<!--
			 <div class="col-md-3 ftr-grid">				
					<h3>Information</h3>
					<ul class="nav-bottom">
						<li><a href="#">Track Order</a></li>
						<li><a href="#">New Products</a></li>
						<li><a href="#">Location</a></li>
						<li><a href="#">Best Sellers</a></li>	

					</ul> 
			 </div>					
					-->					

			 <div class="col-md-3 ftr-grid">
					<a href="seller.shopduct.com" ><h3>Become Seller</h3></a>
					<ul class="nav-bottom">
						<!-- <li><a href="#">FAQ</a></li> -->
						<!-- <li><a href="contact.php">Contact</a></li> -->
							
					</ul>					
			 </div>
			<!-- <div class="col-md-3 ftr-grid">
					<h3>Categories</h3>
					<ul class="nav-bottom">	
						<li><a href="#">Books</a></li>
						<li><a href="#">Electronics</a></li>	
					</ul>					
			 </div> -->
			 <div class="clearfix"></div>
		 </div>
	 </div>
</div>
<div class="copywrite">
	 <div class="container">
		 <div class="copy">
			 <p>© 2015 Shopduct. All Rights Reserved | www.shopduct.com </p>
		 </div>
		 <div class="social">							
				<!--<a href=""><i class="facebook"></i></a>
				<a href="#"><i class="twitter"></i></a>
				<a href="#"><i class="dribble"></i></a>
				<a href="#"><i class="youtube"></i></a> -->	
				<a href="www.google.com/+Shopduct"><i class="google"></i></a>	
					
		 </div>
		 <div class="clearfix"></div>
	 </div>
</div>
<!---->
</body>
</html>
