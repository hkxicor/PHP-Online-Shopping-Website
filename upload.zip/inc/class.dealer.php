<?php
class DEALER{
	private $db;
	private $dealer_id;
	
	function __construct($db_con,$dealer_id){
		$this->db=$db_con;
		$this->dealer_id=($this->isValid($dealer_id))?$dealer_id : 0;
	}
	public function getId(){
		return $this->dealer_id;
	}
	private function isValid($id){
		try{
			$st = $this->db->prepare("select * from dealer where dealer_id=:did");
			$id =(int)$id;
			$st->bindparam(':did',$id);
			$st->execute();
			if($st->rowCount() > 0){
					return true;
				}
			else{
				return false;
			}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function getShopname(){
		try{
			$st = $this->db->prepare("select shop_name from dealer where dealer_id=:did");
			$st->bindparam(':did',$this->dealer_id);
			$st->execute();
			$userRow=$st->fetch(PDO::FETCH_ASSOC);
			if($st->rowCount() > 0){
					return $userRow['shop_name'];
				}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function getShopCity(){
		try{
			$st = $this->db->prepare("select city from dealer where dealer_id=:did");
			$st->bindparam(':did',$this->dealer_id);
			$st->execute();
			$userRow=$st->fetch(PDO::FETCH_ASSOC);
			if($st->rowCount() > 0){
					return $userRow['city'];
				}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	
	
	public function productPrice($pid){
		try{
			$st = $this->db->prepare("select price from dealer_product where dealer_id=:did AND product_id=:pid");
			$st->bindparam(':did',$this->dealer_id);
			$st->bindparam(':pid',$pid);
			$st->execute();
			$st->setFetchMode(PDO::FETCH_ASSOC);
			while($row = $st->fetch()){
					//now get the product price
					return $row['price'];
					//$st1= $this->db->prepare("select price from dealer_product where dealer_id=:did AND product_id=:pid");
					//$st1->bindparam(':did',$this->dealer_id);
					//$st1->bindparam(':pid',$pid);
					//$st1->execute();
					//$userRow1=$st->fetch(PDO::FETCH_ASSOC);
					//if($st1->rowCount()>0){
//						return $userRow1['price'];
	//				}
			}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	
	public function isSuscribed($uid){
		try{
			$st = $this->db->prepare("select id from shop_follow_list where dealer_id=:did AND user_id=:uid");
			$st->bindparam(':did',$this->dealer_id);
			$st->bindparam(':uid',$uid);
			$st->execute();
			if($st->rowCount() > 0){
					return true;
				}
			else{
				return false;
			}	
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
	}
	public function unSuscribe($uid){
		if($this->isSuscribed($uid)){
			try{
			$st = $this->db->prepare("select id from shop_follow_list where dealer_id=:did AND user_id=:uid");
			$st->bindparam(':did',$this->dealer_id);
			$st->bindparam(':uid',$uid);
			$st->execute();
			$userRow=$st->fetch(PDO::FETCH_ASSOC);
			if($st->rowCount() > 0){
					$idRemove = $userRow['id'];
					$st = $this->db->prepare("delete from shop_follow_list where id=:id");
					$st->bindparam(':id',$idRemove);
					$st->execute();
					return $st;
				}
		}
		catch(PDOException $e ){
				echo $e->getMessage();
			}
		}
	}
	
	
	
	
	
}
?>