<?php
include_once './inc/class.packet.php';
class ORDER{
	private $db;
	private $order_id;
	
	function __construct($db_con,$order_id){
		$this->db = $db_con;
		$this->order_id = $order_id;
	}
}
?>