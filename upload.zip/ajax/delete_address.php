<?php
	include('../inc/db.php');
	$id=$_POST['id'];
	$k = mysqli_query($GLOBALS["___mysqli_ston"],"delete from address where id='$id'");
	if($k) {
		
		echo "Deleted";		
		}
		else {
			
				echo "Something Went Wrong Try Again";			
			}
?>