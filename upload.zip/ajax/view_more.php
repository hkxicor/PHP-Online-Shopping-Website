<?php
include("../inc/db.php");
$id=$_POST['id'];
function num_sellers($id) {
				$k=mysqli_query($GLOBALS["___mysqli_ston"], "select * from dealer_product where book_id = '$id'");
				$count = mysqli_num_rows($k);
				return $count;			
			}

$q=mysqli_query($GLOBALS["___mysqli_ston"],"select book_name,auther,publication,edition from cs where book_id='$id'
union
select book_name,auther,publication,edition from ec where book_id='$id'
union
select book_name,auther,publication,edition from eic where book_id='$id'
union
select book_name,auther,publication,edition from ee where book_id='$id'
union
select book_name,auther,publication,edition from civil where book_id='$id'
union
select book_name,auther,publication,edition from mech where book_id='$id'
");

while($row=mysqli_fetch_array($q)){
	$name=$row['book_name'];
	$auther=$row['auther'];
	$publication=$row['publication'];
	$edition=$row['edition'];
}

$return = '<h2>'.$name.'</h2>
			<p><span style="font-size:19px;color:black;">Auther</span>:'." ".$auther.'</p>
			<p><span style="font-size:19px;color:black;">Publication</span>:'.$publication.'</p>
			<p><span style="font-size:19px;color:black;">Edition</span>:'.$edition.'</p>
			<span style="font-size:15px;color:grey;">In Stock</span><br>
			<span style="font-size:15px;color:green;">'.num_sellers($id).' Sellers Near You</span><br>
			<span style="font-size:15px;color:black;">Get off* on second hand books</span>
			<ul class="cd-item-action">
				<li><a href="./result.php?id='.$id.'"><button class="add-to-cart">View more</button></a></li>					
					
			</ul> <!-- cd-item-action -->';
echo $return;
?>