<?php include_once './inc/db.php'; ?>
<?php
		$user = new USER($DB_con);
		$c = new CART($DB_con);
		if(!($user->isLogin())){
			echo "You have to login to add to cart this Product";
			
		}
		else{
			//filter
			$pid = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
			$did = isset($_POST['dealer_id']) ? (int)$_POST['dealer_id'] : 0;
			
			if($c->addToCart($pid,$did)){
				echo "Successfully added to Cart";
				
			}
			else{
				echo "Something Went";
			}
			
		}
		/*
		session_start();
		$id = $_POST['id'];
		
		
		if(isset($_SESSION['user_login'])) {
						 
					$user_login = $_SESSION['user_login'];
					$qty = 1;
					$dealer_id = $_POST['dealer_id'];
					$s=$_POST['s'];
					//check if the product is alredy in cart 
							$q2=mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM cart WHERE product_id='$id' AND dealer_id='$dealer_id' and user_id='$user_login' and s='$s'");
								$q2_count = mysqli_num_rows($q2);
								if($q2_count != 0) {
													//increase qty;
													mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE cart SET qty=qty+1 WHERE product_id='$id' AND dealer_id='$dealer_id' and user_id='$user_login' and s='$s'");
																						echo "Product Alredy in Cart .... Quantity incremented";
									 }
									else {				
					
						$q="INSERT INTO cart(user_id,product_id,qty,dealer_id,s) values('$user_login','$id','$qty','$dealer_id','$s')";
						$r=mysqli_query($GLOBALS["___mysqli_ston"], $q) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
						
						if($r) {
														echo "success fully added to cart";		
							}
						else {
									echo "Something Went Wrong Try Again";							
							}
											
					}						 

			}
			else {
				  
				}
				
				*/
?>