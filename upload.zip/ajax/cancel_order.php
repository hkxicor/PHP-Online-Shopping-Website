<?php
include('../inc/db.php');
	$packet_id=$_POST['id'];
	
	$query="select status from packet where packet_id='$packet_id'";
	$result=mysqli_query($GLOBALS["___mysqli_ston"],$query);
		while($row=mysqli_fetch_array($result)) {
			$status=$row['status'];
		}
		if($status == 1 or $status == 2) {
			
				$query="update packet set status=0 where packet_id='$packet_id'";
	$result=mysqli_query($GLOBALS["___mysqli_ston"],$query);			
	if($result) {
			echo 'Successfully Canceled';		
		}
	else {
				echo 'Something went wrong try again';		
		}
			}
			
			else {
			echo 'Illigal Operation';				
				}

?>