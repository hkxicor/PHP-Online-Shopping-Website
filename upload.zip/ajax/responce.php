<?php 
include("../inc/db.php");

session_start();
	//sanitize post value, PHP filter FILTER_SANITIZE_NUMBER_INT removes all characters except digits, plus and minus sign.
$idToDelete = $_POST['id']; 
	
	//try deleting record using the record ID we received from POST
 	  $delete_row = mysqli_query($GLOBALS["___mysqli_ston"], "DELETE FROM cart WHERE id='$idToDelete' ");
 	  
 	  	
	
  
 ?>