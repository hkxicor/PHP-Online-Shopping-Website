<?php
include('../inc/db.php');
$id=$_POST['id'];
$act=$_POST['act'];

	if($act==1) {
		
		$k=mysqli_query($GLOBALS["___mysqli_ston"], "update cart set qty=qty+1 where id='$id'");
		if($k) {echo 'Incremented';}
		else {echo 'Error';}		
		}
	elseif($act==2) {
				$k=mysqli_query($GLOBALS["___mysqli_ston"], "select qty from cart where id='$id'");
				while($r=mysqli_fetch_array($k)) {
					
						$q=$r['qty'];					
					}	
					if($q<=1) {
						
									echo 'Item Qty cannot be zero';						
						}
						
						else {
									
											$k=mysqli_query($GLOBALS["___mysqli_ston"], "update cart set qty=qty-1 where id='$id'");
		if($k) {echo 'Decremented';}
		else {echo 'Error';}			
							}
		}
	
?>